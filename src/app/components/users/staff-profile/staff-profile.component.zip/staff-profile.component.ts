import { Component } from '@angular/core';

@Component({
  selector: 'app-staff-profile',
  standalone: true,
  imports: [],
  templateUrl: './staff-profile.component.html',
  styleUrl: './staff-profile.component.scss'
})
export class StaffProfileComponent {

}
